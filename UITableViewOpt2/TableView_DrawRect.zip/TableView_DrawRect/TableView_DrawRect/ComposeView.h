//
//  ComposeView.h
//  TableView_DrawRect
//
//  Created by vedon on 19/6/2016.
//  Copyright © 2016 vedon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ComposeView : UIView
- (void)configureWithTitle:(NSString *)title subtitle:(NSString *)subtitle image:(UIImage *)image;
@end
