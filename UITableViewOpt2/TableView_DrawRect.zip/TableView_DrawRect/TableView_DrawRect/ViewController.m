//
//  ViewController.m
//  TableView_DrawRect
//
//  Created by vedon on 19/6/2016.
//  Copyright © 2016 vedon. All rights reserved.
//



//#define kDraw 1

#import "ViewController.h"
#import "ReDrawCell.h"
#import "NomalCell.h"
#import "RedrawCell_Compose.h"
#import "NomalCell_Compose.h"

static NSString *cellIdentifier1 = @"Cell1";
static NSString *cellIdentifier2 = @"Cell2";


@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (strong,nonatomic) UITableView *contentTable;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.contentTable = [[UITableView alloc] initWithFrame:self.view.bounds];
    self.contentTable.dataSource = self;
    self.contentTable.delegate = self;
    [self.contentTable registerClass:[NomalCell_Compose class] forCellReuseIdentifier:cellIdentifier1];
    [self.contentTable registerClass:[RedrawCell_Compose class] forCellReuseIdentifier:cellIdentifier2];
    [self.view addSubview:self.contentTable];
    
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3000;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 180;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
#ifdef kDraw
    RedrawCell_Compose *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier2];
    
#else

    
    NomalCell_Compose *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier1];
#endif
    
    [cell configureWithTitle:[indexPath description] subtitle:@"SubTitle" image:[UIImage imageNamed:@"1.png"]];
    return cell;
}

@end
