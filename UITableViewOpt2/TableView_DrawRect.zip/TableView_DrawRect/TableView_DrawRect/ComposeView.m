//
//  ComposeView.m
//  TableView_DrawRect
//
//  Created by vedon on 19/6/2016.
//  Copyright © 2016 vedon. All rights reserved.
//

#import "ComposeView.h"

@interface ComposeView()
@property (nonatomic,strong) UIImageView *contentImageView;
@property (nonatomic,strong) UILabel *contentTitleLabel;
@property (nonatomic,strong) UILabel *contentSubtitleLabel;

@property (nonatomic,strong) CALayer *imageLayerView;
@property (nonatomic,strong) CATextLayer *titleTextLayer;
@property (nonatomic,strong) CATextLayer *subtitleTextLayer;
@end

@implementation ComposeView


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
//        self.contentImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 100, 60)];
//        self.contentTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(100, 0, 200, 20)];
//        self.contentSubtitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(100, 30, 200, 20)];
//        
//        [self addSubview:self.contentImageView];
//        [self addSubview:self.contentTitleLabel];
//        [self addSubview:self.contentSubtitleLabel];
        
        
        self.imageLayerView = [CALayer layer];
        self.imageLayerView.frame = CGRectMake(0, 0, 100, 60);
        self.imageLayerView.contentsScale = [UIScreen mainScreen].scale;
        
        self.titleTextLayer = [CATextLayer layer];
        self.titleTextLayer.frame = CGRectMake(100, 0, 200, 40);
        self.titleTextLayer.wrapped = YES;
        self.titleTextLayer.contentsScale = [UIScreen mainScreen].scale;
        self.titleTextLayer.alignmentMode = kCAAlignmentJustified;
        
        
        
        
        
        self.subtitleTextLayer = [CATextLayer layer];
        self.subtitleTextLayer.frame = CGRectMake(100, 30, 200, 20);
        self.subtitleTextLayer.wrapped = YES;
        self.subtitleTextLayer.contentsScale = [UIScreen mainScreen].scale;
        self.subtitleTextLayer.foregroundColor = [UIColor blackColor].CGColor;
        UIFont *font = [UIFont systemFontOfSize:10];
        CFStringRef fontName = (__bridge CFStringRef)font.fontName;
        CGFontRef fontRef = CGFontCreateWithFontName(fontName);
        self.subtitleTextLayer.font = fontRef;
        self.subtitleTextLayer.fontSize = 10;
         CGFontRelease(fontRef);
        
        [self.layer addSublayer:self.imageLayerView];
        [self.layer addSublayer:self.titleTextLayer];
        [self.layer addSublayer:self.subtitleTextLayer];
        
        self.layer.drawsAsynchronously = YES;
        
    }
    return self;
}


- (void)configureWithTitle:(NSString *)title subtitle:(NSString *)subtitle image:(UIImage *)image
{
    
    NSMutableParagraphStyle*paragraph = [[NSMutableParagraphStyle alloc]init
                                         ];
    paragraph.
    alignment=NSTextAlignmentJustified;
    paragraph.firstLineHeadIndent=20.0;
    paragraph.paragraphSpacingBefore=10.0;
    paragraph.lineSpacing=5;
    
    UIColor *foregroundColor = [UIColor blueColor];
    NSNumber *kern = [NSNumber numberWithFloat:5.0];
    NSNumber *ligature = [NSNumber numberWithFloat:3.0];
    NSNumber *underline = [NSNumber numberWithInt:NSUnderlineStyleSingle];
    NSDictionary *attrsDic = @{NSForegroundColorAttributeName: foregroundColor,
                               NSKernAttributeName: kern,
                               NSLigatureAttributeName: ligature,
                               NSUnderlineStyleAttributeName: underline,
                               NSFontAttributeName:[UIFont systemFontOfSize:12],
                               NSParagraphStyleAttributeName:paragraph
                               };
    
    NSAttributedString *attribute = [[NSAttributedString alloc] initWithString:title attributes:attrsDic];
    
    self.imageLayerView.contents = (__bridge id _Nullable)(image.CGImage);
    self.titleTextLayer.string = attribute;
    self.subtitleTextLayer.string = subtitle;
    
//    self.contentTitleLabel.attributedText = attribute;
//    self.contentSubtitleLabel.text = subtitle;
//    
//    
////    self.contentTitleLabel.text = title;
////    self.contentSubtitleLabel.text = subtitle;
//
//    self.contentImageView.image = image;

}
@end
