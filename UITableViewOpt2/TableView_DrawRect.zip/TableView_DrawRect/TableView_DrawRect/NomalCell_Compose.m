//
//  NomalCell_Compose.m
//  TableView_DrawRect
//
//  Created by vedon on 19/6/2016.
//  Copyright © 2016 vedon. All rights reserved.
//

#import "NomalCell_Compose.h"
#import "ComposeView.h"

@interface NomalCell_Compose()
@property (nonatomic,strong) ComposeView *composeView1;
@property (nonatomic,strong) ComposeView *composeView2;
@property (nonatomic,strong) ComposeView *composeView3;
@end

@implementation NomalCell_Compose

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
       
        self.composeView1 = [[ComposeView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.contentView.frame), 60)];
        self.composeView2 = [[ComposeView alloc] initWithFrame:CGRectMake(0, 60, CGRectGetWidth(self.contentView.frame), 60)];
        self.composeView3 = [[ComposeView alloc] initWithFrame:CGRectMake(0, 120, CGRectGetWidth(self.contentView.frame), 60)];
        [self.contentView addSubview:self.composeView1];
        [self.contentView addSubview:self.composeView2];
        [self.contentView addSubview:self.composeView3];
    }
    return self;
}



- (void)configureWithTitle:(NSString *)title subtitle:(NSString *)subtitle image:(UIImage *)image
{
    [self.composeView1 configureWithTitle:title subtitle:subtitle image:image];
    [self.composeView2 configureWithTitle:title subtitle:subtitle image:image];
    [self.composeView3 configureWithTitle:title subtitle:subtitle image:image];
    
}
@end
