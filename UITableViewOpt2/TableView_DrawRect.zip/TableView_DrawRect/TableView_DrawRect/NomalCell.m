//
//  NomalCell.m
//  TableView_DrawRect
//
//  Created by vedon on 19/6/2016.
//  Copyright © 2016 vedon. All rights reserved.
//

#import "NomalCell.h"

@interface NomalCell ()
@property (strong,nonatomic) UILabel *contentLabel;
@end

@implementation NomalCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.contentLabel = [[UILabel alloc] initWithFrame:self.bounds];
        [self.contentView addSubview:self.contentLabel];
    }
    return  self;
}

- (void)configureWithContent:(NSAttributedString *)string
{
    self.contentLabel.attributedText = string;
}

@end
