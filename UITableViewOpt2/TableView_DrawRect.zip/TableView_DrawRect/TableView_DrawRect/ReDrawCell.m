//
//  ReDrawCell.m
//  TableView_DrawRect
//
//  Created by vedon on 19/6/2016.
//  Copyright © 2016 vedon. All rights reserved.
//

#import "ReDrawCell.h"

@interface ReDrawCell ()
@property (strong,nonatomic) NSAttributedString *attributeString;
@end

@implementation ReDrawCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
//        self.layer.drawsAsynchronously = YES;
    }
    return  self;
}


- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    [self.attributeString drawInRect:rect];
}

- (void)configureWithContent:(NSAttributedString *)string
{
    self.attributeString = string;
    
    [self setNeedsDisplay];
}
@end
