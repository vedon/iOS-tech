//
//  ComposeView_Redraw.m
//  TableView_DrawRect
//
//  Created by vedon on 19/6/2016.
//  Copyright © 2016 vedon. All rights reserved.
//

#import "ComposeView_Redraw.h"

@interface ComposeView_Redraw ()
@property (nonatomic,strong) NSAttributedString *title;
@property (nonatomic,strong) NSString *subtitle;
@property (nonatomic,strong) UIImage *image;
@end

@implementation ComposeView_Redraw

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.layer.drawsAsynchronously = YES;
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    
    [self.title drawInRect:CGRectMake(100, 0, 200, 40)];
    

    [self.subtitle drawInRect:CGRectMake(100, 40, 200, 20) withAttributes:nil];
    [self.image drawInRect:CGRectMake(0,0 , 100, 60)];
    
}


- (void)configureWithTitle:(NSString *)title subtitle:(NSString *)subtitle image:(UIImage *)image
{
    NSMutableParagraphStyle*paragraph = [[NSMutableParagraphStyle alloc]init
                                         ];
    paragraph.
    alignment=NSTextAlignmentJustified;
    paragraph.firstLineHeadIndent=20.0;
    paragraph.paragraphSpacingBefore=10.0;
    paragraph.lineSpacing=5;
    
    UIColor *foregroundColor = [UIColor blueColor];
    NSNumber *kern = [NSNumber numberWithFloat:5.0];
    NSNumber *ligature = [NSNumber numberWithFloat:3.0];
    NSNumber *underline = [NSNumber numberWithInt:NSUnderlineStyleSingle];
    NSDictionary *attrsDic = @{NSForegroundColorAttributeName: foregroundColor,
                               NSKernAttributeName: kern,
                               NSLigatureAttributeName: ligature,
                               NSUnderlineStyleAttributeName: underline,
                               NSFontAttributeName:[UIFont systemFontOfSize:12],
                               NSParagraphStyleAttributeName:paragraph
                               };
    
    NSAttributedString *attribute = [[NSAttributedString alloc] initWithString:title attributes:attrsDic];
    

    
    self.title = attribute;
    self.subtitle = subtitle;
    self.image = image;
    
    [self setNeedsDisplay];
}

@end
