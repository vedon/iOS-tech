#!/usr/bin/env ruby

#require_relative("colored2.rb")
require 'colored2'

module Color
    class  ColoredInput
        
        attr_reader :filePath
        def  initialize(inputFilePath)
            @filePath = inputFilePath
        end
        
        def  Colored
            fileContent = File.read(@filePath)
            fileContent.gsub!("Class :","Class :".magenta)
            fileContent.gsub!("Class: ","Class :".magenta)
            fileContent.gsub!(/[-+]\s\(\w*\).*;/,"\\0".cyan.bold)
            fileContent.gsub!(/\w*[^ :]\(\w*\)/,"\\0".red.bold)
            puts fileContent

        end
    end
end


file_Path = ARGV.shift
object = Color::ColoredInput.new(file_Path)
object.Colored
