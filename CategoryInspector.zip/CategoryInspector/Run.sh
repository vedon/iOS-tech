

rm -f ./outputFile

./CategoryInspector -m $1 >> outputFile
chmod 775 ./Colored.sh
./Colored.sh  "./outputFile"

rm -f ./outputFile
